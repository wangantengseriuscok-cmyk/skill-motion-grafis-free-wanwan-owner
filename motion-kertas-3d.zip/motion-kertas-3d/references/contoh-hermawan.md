# Contoh Lengkap: Perkenalan Hermawan, MPLS 2025 (10 detik)

Contoh ini menunjukkan cara mengubah brief menjadi video. Cerita, tokoh, dan dunia dibuat
**orisinal** untuk brief ini; hanya *gaya visual* yang mengikuti DNA di `gaya-visual.md`.

## Brief
- Tokoh: Hermawan, 12 tahun, siswa baru SMP YKTB Kota Bogor, tinggal di Menteng.
- Acara: MPLS 2025.
- Format: 9:16, 30 fps, 10 detik (300 frame), VO Indonesia, subtitle tengah-bawah.
- Hal yang tidak diberikan pengguna dan tidak boleh dikarang: logo, warna resmi, nama guru,
  alamat. Papan nama sekolah memakai teks biasa. Menteng tidak digambarkan sebagai tempat
  tertentu, hanya "lingkungan rumah" generik (rumah warga, pohon, gunung di latar).

## Naskah VO (25 kata ≈ 9,5 detik)
> Halo semuanya! Aku Hermawan, umur 12 tahun. Aku tinggal di Menteng, siswa baru SMP YKTB
> Kota Bogor. Siap MPLS 2025! Salam kenal!

## Beat sheet
| Beat | Waktu | Subtitle | Visual | Kamera | SFX |
|---|---|---|---|---|---|
| A | 0,0–2,0 | "Halo semuanya!" | Hermawan loncat masuk dari bawah, mendarat, melambai, mata girang | Dolly in dari jauh, orbit kecil | whoosh (0,18), pop (0,55), boing (0,6) |
| B | 2,0–4,4 | "Aku Hermawan, umur 12 tahun" | Papan nama kardus "HERMAWAN" muncul dengan pop; stiker kuning "12 TAHUN" jatuh pop di atas kepala | Dolly in ke wajah + naik pelan agar papan nama di atas subtitle | whoosh (1,9), pop (2,35), sparkle (2,95) |
| C | 4,4–8,0 | "Aku tinggal di Menteng," lalu "siswa baru SMP YKTB Kota Bogor" | Hermawan berjalan goyang melewati rumah warga menuju gerbang sekolah | Dolly out lalu truck kanan mengikuti; parallax rumah, pohon, gunung | langkah ×6 (4,5 s.d. 6,25), whoosh rendah (6,1), bel (7,4) |
| D | 8,0–10,0 | "Siap MPLS 2025! Salam kenal!" | Dua teman muncul dari bawah (satu berhijab), spanduk "MPLS 2025" berayun, konfeti kertas 3D jatuh, Hermawan melambai | Dolly out pelan + orbit | pop ×2 (8,0 / 8,12), whoosh (8,3), konfeti (8,45), sparkle (9,65) |

Kata kunci kuning pada subtitle: Hermawan, 12, Menteng, YKTB, MPLS, 2025.

## Cara komposisi ini dibuat
File: `assets/starter/src/scenes/HermawanIntro.tsx`
- `CUES` = subtitle, `SFX` = daftar cue bunyi, `SPEECH` = jam bicara (dipakai lip-sync dan ducking).
- `camAt(frame)` = satu gerakan kamera per beat.
- Lapisan dunia dari z = -1100 (langit) sampai +120 (stiker), lalu karakter dan konfeti.
- Karakter: `Kid` dengan `outfit="seragam"`, `tag="HERMAWAN"`, `backpack`, dua teman dengan
  `hairStyle="hijab"` dan `"spiky"`.

## Mengadaptasi untuk cerita lain
1. Ganti `NAME`, `SCHOOL_SIGN`, `CUES`, `SFX`, dan teks stiker/spanduk.
2. Ganti isi dunia (rumah → toko, gerbang → pintu kelas, dll.) tanpa mengubah komponen gaya.
3. Ganti ekspresi dan alis pada titik emosi cerita barumu.
4. Perpanjang durasi dengan menambah beat (±2–3 detik per beat) dan menyesuaikan
   `VIDEO.durationInSeconds` di `config.ts`.
5. Jalankan: `npm run typecheck`, still frame kunci, lalu render.
