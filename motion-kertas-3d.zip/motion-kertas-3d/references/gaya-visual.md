# Spesifikasi Gaya Visual — Motion Kertas 3D

Daftar isi: 1. Palet · 2. Karakter · 3. Ekspresi · 4. Dunia · 5. Kamera · 6. Cahaya · 7. Subtitle · 8. Rasa kertas · 9. Anti-pola

Baca file ini saat membuat karakter atau dunia baru. Tujuannya satu: apa pun ceritanya,
hasilnya harus terlihat seperti dari "studio" yang sama.

## 1. Palet
- Tinta: `#1B1530` (hitam keunguan, bukan hitam murni; terasa lebih hangat).
- Kulit: tiga nada di `Kid.tsx` (`light`, `mid`, `deep`), masing-masing gradasi atas-bawah.
- Satu adegan = satu keluarga warna. Siang: langit biru `#5FB0FF → #C6E6FF`, rumput `#46A233`,
  tanah `#D9B27C`. Malam: dinding `#2F4B80`, kayu `#7A4A24`, aksen merah `#B8281E`.
- Aksen: kuning `#FFD84D` untuk kata kunci dan stiker. Maksimal 1 warna aksen dominan per adegan.
- Hindari gradasi rumit, tekstur foto, dan bayangan lembut besar pada karakter. Bayangan hanya
  di tanah (elips blur) atau offset keras pada stiker.

## 2. Karakter
- Viewbox 400 x 640. Kepala lingkaran r=140 (lebar 280) dan badan kapsul lebar 156 → kepala
  hampir dua kali lebar badan. Itu proporsi kunci gaya ini.
- Kaki lidi (tinta, tebal 12) dengan telapak elips. Tangan tabung berwarna lengan, ujungnya
  lingkaran kulit tanpa jari. Lengan panjang 135 supaya lambaian terbaca di luar kepala.
- Rambut: tutup kepala dengan poni zig-zag. Variasi: `rapi` (satu jambul), `spiky` (3 duri),
  `bob`, `hijab`. Warna rambut gelap hampir sama dengan tinta supaya menyatu dengan kontur.
- Baju: `seragam` (kemeja putih, kerah, dasi, bawahan biru tua), `hoodie` (garis leher + tali putih),
  `tee`. Tambahan: ransel, papan nama kardus.
- Tiap tokoh baru: ganti props, bukan bentuk dasar. Beri satu ciri siluet unik.
- Karakter selalu menghadap depan (gaya kertas datar). Gerak "berjalan" dibuat dengan goyang
  miring + loncat kecil + kaki berayun, bukan tampak samping.

## 3. Ekspresi (kombinasi props)
| Perasaan | eyes | mouth | brow |
|---|---|---|---|
| Girang | `happy` | `grin` (mouthOpen 0.6–1) | tanpa alis |
| Kaget | `surprised` | `open` (0.8) | +0.6, browLift -14 |
| Jengkel / bosan | `bored` | `frown` atau `flat` | -0.8 |
| Normal / mendengar | `open` | `smile` | tanpa alis |
| Bicara | `open` | `grin` dengan mouthOpen bergerak | opsional |
Ganti ekspresi pada **titik emosi cerita**, bukan setiap detik. Ekspresi yang bertahan lama
terasa lebih kuat daripada yang berubah-ubah.

## 4. Dunia
- Siluet dulu: gunung, bukit, atap, pohon cemara berupa segitiga/poligon datar dengan garis
  tipis. Detail kecil (jendela, pagar, tali) boleh, tetapi tidak boleh bersaing dengan wajah.
- Lantai datar berwarna kontras dengan karakter. Jalan setapak memberi arah gerak.
- Tempat identitas (gerbang sekolah, papan nama, spanduk) ditulis dengan huruf tebal dan
  kontras tinggi. Teks pada properti harus terbaca di ukuran thumbnail.
- Isi dunia disesuaikan cerita. Referensi screenshot hanya menentukan *cara menggambar*.

## 5. Kamera
- Satu gerakan per beat. Dolly in untuk emosi, dolly out untuk konteks, truck (geser) untuk
  perjalanan. Gerakan selalu ease in-out.
- Orbit `rotY` kecil (±2–6°) hampir sepanjang video agar tepi kertas dan parallax terlihat.
- Blur latar 2–4 px saat dolly in ke wajah (depth of field murah).
- Zona aman vertikal: 150 px atas dan 300 px bawah bebas dari teks penting (UI aplikasi).

## 6. Cahaya dan warna
- Vignette 0.25–0.35. Siang: tanpa grade atau sedikit hangat. Malam: overlay biru `multiply`
  + prop `night` pada wajah.
- Jangan campur dua mood dalam satu frame kecuali transisi disengaja.

## 7. Subtitle
- Poppins/Montserrat ExtraBold 70 px (di 1080 lebar), putih, kontur hitam ±12 px dengan
  `paint-order: stroke fill`, bayangan 7 px. Tengah-bawah, `bottom: 300`.
- 1–6 kata sekali tampil, maksimal 2 baris. Kata kunci kuning (nama, angka, tempat).
- Muncul dengan pop kecil (scale 0.82 → 1). Waktu tampil mengikuti VO, jangan mendahului.

## 8. Rasa kertas
- `PaperGrain` (serat statis, multiply 0.2), `thickness` pada lapis karakter dan properti
  utama, `GroundShadow` di bawah kaki.
- `boil` (garis bergetar 3 frame sekali) dan gerak "on twos" membuat terasa digambar tangan.
- Konfeti dan stiker dirotasi pada sumbu X dan Y sekaligus supaya jelas berupa lembar 3D.

## 9. Anti-pola
- Menggambar ulang karakter/adegan dari screenshot referensi.
- Gradasi dan bayangan lembut pada karakter (merusak kesan kertas datar).
- Gerak linear tanpa easing, objek muncul tanpa pop, kamera diam seluruh video.
- Subtitle satu kalimat panjang, atau berada di atas wajah.
- Terlalu banyak elemen di latar sehingga wajah tidak menjadi fokus.
- Menambah logo/warna/fakta sekolah atau merek yang tidak diberikan pengguna.
