# Sound Effect dan Audio untuk Motion Kertas 3D

Daftar isi: 1. Cara berpikir · 2. Menurunkan cue dari beat sheet · 3. Peta aksi → SFX ·
4. Menyesuaikan dengan mood · 5. Timing · 6. Mixing · 7. Sumber dan lisensi ·
8. Kode Remotion · 9. Checklist

## 1. Cara berpikir
SFX di video kertas berfungsi sebagai "berat" dari benda yang sebenarnya ringan. Kertas datar
tidak berbunyi apa-apa, jadi bunyi yang menyampaikan benturan, kecepatan, dan emosi.
Tiga aturan:
1. **Setiap bunyi punya alasan visual.** Kalau tidak ada gerak yang bisa ditunjuk, hapus bunyinya.
2. **Bunyi besar untuk gerak besar.** Lompatan masuk = whoosh + pop + boing; kedipan mata = tidak perlu bunyi.
3. **Hening juga bunyi.** Sisakan 0,2–0,5 detik tanpa SFX sebelum punchline atau momen penting.

## 2. Menurunkan cue dari beat sheet
Untuk tiap baris beat sheet, tulis semua "peristiwa gerak", lalu beri cue:

| Peristiwa | Cue |
|---|---|
| Objek/karakter masuk cepat | whoosh (mulai lebih awal) |
| Objek muncul / mendarat | pop atau thud kecil |
| Squash & stretch | boing (lembut, volume rendah) |
| Teks/stiker muncul | pop + sparkle atau ding |
| Papan nama / angka penting | ding atau "tik" tajam |
| Kamera dolly cepat | whoosh rendah, lebih panjang |
| Berjalan | langkah per ±0,33 detik, selaras dengan loncatan |
| Pergantian adegan | whoosh kertas atau sapuan |
| Bel / tanda waktu | bel (sekolah), klakson, notifikasi |
| Perayaan | letupan konfeti + sorak anak-anak |
| Penutup | ding/sting pendek tepat di frame terakhir bermakna |

Format cue di kode (`SfxCue`): `{at: detik, file, volume, rate, lead}`.

## 3. Peta aksi → karakter bunyi
| Karakter bunyi | Dipakai untuk | Catatan |
|---|---|---|
| Pop (nada turun cepat) | muncul, stiker, teman muncul | ganti `rate` 1.0 / 1.15 / 1.2 untuk variasi |
| Whoosh (noise menyapu) | masuk, kamera, transisi | durasi mengikuti gerak; gerak pelan = rate 0.8 |
| Boing (pegas) | mendarat, kaget | volume ≤0.4, jangan di tiap gerak |
| Thud/langkah | berjalan | 3–4 variasi `rate` 0.95–1.06 agar tidak seperti mesin |
| Ding / sparkle | info penting, hasil | jangan lebih dari 3 kali per video |
| Bel | latar sekolah, penanda waktu | satu kali, bukan loop |
| Konfeti/sorak | perayaan | taruh tepat saat konfeti keluar |
| Ambience (angin, burung, ruang) | latar adegan | loop sangat pelan (0.08–0.15) |

## 4. Menyesuaikan dengan mood dan karakter
- **Ceria / sekolah / perkenalan**: pop, ding, boing, ukulele atau pizzicato ringan 100–120 BPM.
- **Lucu / canggung**: boing, slide whistle, "record scratch" untuk jeda, hening sebelum punchline.
- **Jengkel / kecewa** (pesan tidak dibalas, jam berdetak): tik-tok jam, dengung rendah, nada turun.
- **Tegang / misteri**: dengung rendah, tik pelan, whoosh yang terbalik (riser) sebelum kejutan.
- **Haru / tenang**: ambience, piano atau gitar lembut, kurangi SFX, pakai bunyi bahan (kertas, langkah).
- **Energik / promosi**: whoosh rapat, impact kecil di tiap pergantian teks, musik 120–140 BPM.
Karakter anak/remaja: bunyi ringan dan cerah (nada tinggi, pendek). Karakter dewasa atau
adegan serius: bunyi lebih rendah dan pendek. Properti besar (gerbang, spanduk) mendapat bunyi
lebih rendah daripada properti kecil (stiker).

## 5. Timing
- Bunyi mulai di **frame benturan**, bukan frame awal gerak. Pop tepat di frame objek muncul.
- Whoosh mulai 3–5 frame (0,1–0,15 s) sebelum objek sampai: pakai `lead`.
- Ketukan langkah selaras dengan puncak loncatan kaki (di bawah), bukan di puncak atas.
- Jangan menumpuk lebih dari 3 bunyi dalam jendela 0,2 detik.
- Bunyi berulang: variasikan `rate` ±5% dan `volume` ±10%.
- Hindari SFX yang menutupi kata kunci VO: geser 0,1–0,2 detik atau turunkan volume.
- Musik: sebaiknya ketukan kuat selaras dengan pergantian beat (potong atau geser musik, bukan kamera).

## 6. Mixing
Acuan relatif (VO sebagai jangkar):
| Lapisan | Level kira-kira |
|---|---|
| Voice over | 1.0 (referensi), target keseluruhan sekitar −14 LUFS dan puncak di bawah −1 dBTP |
| SFX | 0.3–0.7, aksen besar boleh sampai 0.8 |
| Musik | 0.25–0.30 saat tanpa bicara, **ducking ke 0.10–0.14** saat VO bicara |
| Ambience | 0.08–0.15 |
- Ducking turun cepat (≈0,1 s) dan naik pelan (≈0,35 s) agar tidak "memompa". Komponen `Music`
  di starter melakukan ini dari daftar jam bicara.
- Fade-out musik 0,8 detik di akhir.
- Cek di speaker ponsel, bukan hanya headphone: bunyi rendah (<150 Hz) hilang di ponsel.
- Jika tidak ada VO, SFX dan musik boleh lebih besar (SFX 0.5–0.9, musik 0.35–0.5).

## 7. Sumber dan lisensi
- Buat sendiri: `npm run sfx` menghasilkan placeholder sintetis (aman dipakai, tetapi sederhana).
- Pustaka bebas/berlisensi yang umum dipakai: Pixabay, Freesound (cek lisensi tiap bunyi, ada yang
  CC0 dan ada yang wajib atribusi), Mixkit, YouTube Audio Library.
- Selalu cek lisensi tiap file, terutama jika video akan dimonetisasi atau dipakai iklan/sekolah
  secara resmi. Simpan daftar sumber di `public/CREDITS.md`.
- Nama file konsisten (`pop.wav`, `whoosh.wav`, `step.wav`, dst.) supaya mengganti placeholder
  dengan file asli cukup menimpa file tanpa mengubah kode.
- Format WAV atau MP3 44,1/48 kHz. Potong keheningan di awal file agar cue tepat.

## 8. Kode Remotion
```tsx
import {SfxTrack, Music, SfxCue} from '../lib/Sfx';

const SFX: SfxCue[] = [
  {at: 0.30, file: 'whoosh.wav', volume: 0.5, lead: 0.12},   // masuk
  {at: 0.55, file: 'pop.wav',    volume: 0.7},               // mendarat
  {at: 4.50, file: 'step.wav',   volume: 0.5, rate: 0.95},   // langkah
];
const SPEECH: Array<[number, number]> = [[0.2, 1.95], [2.0, 4.35]];

<SfxTrack cues={SFX} />
<Music file="audio/music.mp3" speech={SPEECH} base={0.28} duck={0.12} />
{/* VO: <Audio src={staticFile('audio/vo.mp3')} /> */}
```
Letakkan VO di `public/audio/vo.mp3` dan setel `AUDIO.hasVoiceOver = true`. Setelah VO asli ada,
ukur jam bicara sebenarnya dan perbarui `CUES` + `SPEECH` supaya subtitle dan lip-sync pas.

## 9. Checklist
- [ ] Tiap cue punya peristiwa visual yang jelas
- [ ] Whoosh punya `lead`, pop tepat di frame muncul
- [ ] Bunyi berulang divariasikan (`rate`, `volume`)
- [ ] Ada jeda hening sebelum momen penting
- [ ] Musik di-duck saat VO; VO selalu jelas
- [ ] Lisensi semua file tercatat
- [ ] Sudah didengar di speaker ponsel
