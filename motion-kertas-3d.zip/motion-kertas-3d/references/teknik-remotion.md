# Teknik Remotion untuk "Kertas di Dunia 3D"

Daftar isi: 1. Model 3D · 2. Kamera · 3. Tepi kertas · 4. Garis bergetar · 5. Gerak on twos ·
6. Struktur proyek · 7. Memperluas starter · 8. Jebakan umum

## 1. Model 3D
`World` membuat konteks CSS 3D (`perspective: 1400px`, `transform-style: preserve-3d`).
Setiap `Layer` adalah lembar datar di kedalaman `z`. Browser mengurus perspektif, jadi:
- lapis jauh mengecil, dan bergeser lebih sedikit saat kamera bergerak (parallax);
- `fit` mengalikan ukuran dan posisi lembar dengan `(1400 - z) / 1400` agar pada kamera nol
  lembar itu tampil sebesar ukuran desain. Pakai untuk lapis dengan `z < -200`;
- objek dekat (`z` 0 s.d. +120) tidak pakai `fit`, jadi ukurannya langsung dalam piksel layar.

Posisi `x`/`y` Layer = pusat lembar relatif ke tengah layar (pada kamera nol).

## 2. Kamera
`Cam {x, y, z, rotX, rotY, rotZ}` diterapkan sebagai transform dunia:
`translate3d(-x, -y, z) rotateX rotateY rotateZ`.
- `z` positif = dolly in. `y` positif = dunia naik (melihat bagian bawah). `x` positif = melihat ke kanan.
- Tulis fungsi `camAt(frame)` murni (tanpa state) memakai `ramp()` per beat.
- Untuk menjaga subjek di tengah saat dolly in, naikkan `y` bersamaan (lihat `HermawanIntro.tsx`).

## 3. Tepi kertas
Prop `thickness={2..3}` pada `Layer` menggandakan isi lembar di belakangnya (translateZ -2,5 px
per salinan, lebih gelap). Tepi hanya tampak saat kamera berputar (`rotY`). Pakai untuk karakter
dan properti utama saja. Pada lapis dengan `blur` jangan dipakai (filter meratakan 3D).

## 4. Garis bergetar (boil)
`Kid` menerima `boil={Math.floor(frame/3)}`: filter SVG `feTurbulence` + `feDisplacementMap`
(skala 5) dengan seed berganti tiap 3 frame. Filter id harus unik per karakter (`uid`).
Matikan dengan tidak memberi prop `boil` bila render terlalu lambat.

## 5. Gerak on twos
`hold(frame, 2)` membekukan frame ke kelipatan 2. Pakai untuk lambaian, mulut, langkah.
Jangan pakai untuk kamera (kamera harus mulus) dan teks.

## 6. Struktur proyek
```
src/
  index.ts            registerRoot
  Root.tsx            daftar komposisi
  config.ts           ukuran, fps, durasi, flag audio
  lib/                World3D, Paper, Subtitle, Sfx, motion, palette  (GAYA — jangan diubah sembarangan)
  characters/Kid.tsx  karakter parametrik
  props/Scenery.tsx   gunung, bukit, rumah, gerbang, spanduk, konfeti, lantai
  scenes/             satu file per video (ubah bagian DATA CERITA)
public/sfx, public/audio   aset audio
scripts/make-sfx.mjs       SFX placeholder
```

## 7. Memperluas starter
- Properti baru (kamar, kelas, kantin, jalan raya): tambahkan ke `Scenery.tsx` dengan pola
  yang sama: SVG datar, `stroke={INK}`, `strokeLinejoin="round"`, ukuran lewat prop `w`.
- Gaya rambut/baju baru: tambahkan nilai pada union type di `Kid.tsx` dan satu cabang gambar.
- Adegan malam: ganti `SkyGradient` dengan dinding berwarna `NIGHT.wall`, tambah `Grade` biru
  (`rgba(30,50,130,0.35)`, mode `multiply`) dan beri prop `night={1}` pada `Kid`.
- Transisi antar adegan: gunakan `Sequence` + lembar kertas besar yang menyapu layar (Layer
  dengan `x` bergerak cepat) alih-alih fade, agar tetap terasa kertas.
- Beberapa adegan: bungkus tiap adegan dalam `<Sequence from durationInFrames>`; waktu lokal
  mulai dari 0 di dalam Sequence.

## 8. Jebakan umum
- **Satu core CPU**: `--concurrency` ≤ jumlah core, jika tidak render langsung gagal.
- **Chrome tidak bisa diunduh**: gunakan `--browser-executable` + `--chrome-mode=headless-shell`.
- **`staticFile` ke file yang tidak ada** membuat render gagal. Atur `AUDIO.*` di config.
- **Lantai miring (rotX besar)** dengan sisi dekat mendekati bidang kamera mudah bolong/pecah.
  Gunakan lantai datar; kedalaman cukup dari parallax.
- **Acak**: jangan `Math.random()`. Pakai `jitter(seed)` agar tiap frame konsisten.
- **Animasi CSS/transition** tidak ikut render. Semua harus dari `useCurrentFrame`.
- **Teks pada SVG** bergantung font. Beri fallback dan ukur terbaca di still sebelum render penuh.
- **Waktu render**: kompleksitas utama ada di filter SVG dan `thickness`. Untuk draf cepat render
  dengan `--scale=0.5` atau matikan `boil`.
