---
name: motion-kertas-3d
description: Membuat video motion grafis pendek bergaya karakter kartun 2D seperti kertas yang bergerak di dunia 3D berlapis (parallax, kamera dolly, garis tinta tebal, warna datar bersih, subtitle tebal ala konten sosmed), lengkap dengan saran sound effect dan musik, memakai kode Remotion (React). Gunakan skill ini setiap kali pengguna minta video motion grafis, animasi karakter kartun, video perkenalan animasi, konten Reels/TikTok/Shorts animasi, video MPLS atau sekolah animasi, "karakter kertas di dunia 3D", atau menyebut gaya visual dari screenshot referensi animasi 2D mereka, walaupun mereka tidak menyebut Remotion atau skill ini.
---

# Motion Kertas 3D (Remotion)

Skill ini membuat video pendek vertikal (default 1080x1920, 30 fps, 8–30 detik) dengan satu
identitas visual yang konsisten: **karakter 2D tebal bergaris tinta, berdiri seperti potongan
kertas di dalam dunia yang punya kedalaman 3D.** Hasil harus terasa seperti produksi serius,
bukan slide yang digerakkan.

Semua teks yang tampil di video dan semua balasan ke pengguna memakai **Bahasa Indonesia**,
kecuali pengguna meminta bahasa lain.

## Prinsip nomor satu: ambil GAYA, bukan ISI

Pengguna biasanya memberi screenshot dari video animasi yang mereka sukai. Screenshot itu
patokan **bahasa visual** (garis, warna, proporsi, kamera, subtitle), bukan konten untuk
digambar ulang. Jadi:

- Jangan menggambar ulang karakter, adegan, properti, atau dialog yang ada di screenshot
  (misalnya tokoh tertentu, jam dinding, layangan). Karakter dan dunia harus **orisinal** dan
  mengikuti cerita yang diminta pengguna.
- Ekstrak aturan gayanya (lihat bagian DNA Visual) lalu terapkan ke cerita apa pun.
- Alasannya: pengguna ingin satu gaya yang bisa dipakai berulang untuk banyak cerita, dan
  menyalin karakter orang lain bermasalah secara hak cipta.

## DNA Visual (ringkas — detail di `references/gaya-visual.md`)

| Elemen | Aturan |
|---|---|
| Garis | Tinta gelap keunguan `#1B1530`. Karakter 10–12 px, properti dekat 5–6 px, latar jauh hanya garis tipis. Ketebalan garis menurun dengan jarak, itu yang memberi kesan kedalaman |
| Warna | Datar dan bersih, maksimal 1 gradasi halus per objek (kulit atas ke bawah). Satu palet per adegan (siang cerah, malam biru, dst.) |
| Karakter | Kepala bulat sangat besar (±45% tinggi tubuh), badan kapsul, kaki lidi, tangan tabung tanpa jari. Wajah minimalis: mata bulat putih + pupil titik, atau garis setengah tertutup, alis tebal, mulut sederhana |
| Ekspresi | Berlebihan dan terbaca dalam 0,2 detik (kaget, jengkel, girang). Ekspresi adalah sumber komedi dan emosi |
| Dunia | Berlapis-lapis seperti diorama kertas: langit, gunung, bukit, bangunan, pohon, lantai, karakter. Tiap lapis di kedalaman (z) berbeda |
| Kamera | Close-up ekstrem boleh memotong kepala di frame. Dorong masuk (dolly in) saat emosi naik, tarik keluar saat konteks. Latar jauh sedikit blur saat fokus ke wajah |
| Cahaya | Satu mood per adegan lewat overlay warna + vignette. Malam = tint biru dan bagian bawah wajah keunguan |
| Subtitle | Putih tebal + kontur hitam tebal, tengah-bawah, 1–6 kata sekali tampil, kata kunci berwarna kuning |
| Rasa kertas | Serat kertas halus, tepi kertas bertebal, bayangan jatuh, garis sedikit bergetar (boil), gerak karakter "on twos" |

## Alur kerja

Ikuti urutan ini. Jangan loncat ke kode sebelum beat sheet disetujui secara implisit
(cukup ditulis ringkas di balasan, tidak perlu menunggu persetujuan kecuali brief kosong).

### 0. Tangkap brief
Kumpulkan: topik/cerita, durasi, tokoh (nama, usia, ciri), naskah voice over (VO) bila ada,
platform (default 9:16), aset yang tersedia (VO, musik, logo, warna). Pakai apa yang sudah
ada di percakapan. Hanya bertanya jika sesuatu benar-benar menghalangi (misalnya tidak ada
topik sama sekali), maksimal satu pertanyaan, selebihnya buat asumsi dan tulis di balasan.

### 1. Naskah dan beat sheet
- Kecepatan bicara Indonesia santai sekitar 2,5–3 kata per detik. Naskah 10 detik = 24–28 kata.
- Bagi menjadi 3–5 beat, satu ide per beat, tiap beat 1,5–3 detik. Beat pertama harus
  memikat dalam 1 detik (karakter muncul dengan gerak besar + sapaan).
- Tulis tabel: waktu | kata/subtitle | visual | kamera | SFX. Tabel ini adalah satu-satunya
  sumber kebenaran; kode scene membaca angka dari sana.
- Contoh lengkap: `references/contoh-hermawan.md`.

### 2. Karakter
Buat karakter dengan komponen `Kid` di starter (props: kulit, rambut, gaya rambut, baju,
ekspresi, alis, ransel, papan nama, dll.). Setiap tokoh baru cukup ganti props, bentuk dasar
tidak diubah supaya gaya tetap satu keluarga. Beri tiap tokoh 1–2 ciri pembeda yang
bisa dibaca siluetnya (jambul, hijab, bob, ransel berwarna). Cek dulu lewat komposisi
`CharacterSheet` sebelum membuat scene.

Tokoh dari cerita nyata Indonesia: pakai atribut yang sesuai konteks (seragam putih-biru SMP,
papan nama karton MPLS, hijab sebagai variasi, ransel). Jangan mengarang logo, warna, atau
fakta sekolah. Kalau pengguna tidak memberi logo/warna resmi, pakai papan nama teks
sederhana dan sebut asumsinya.

### 3. Dunia berlapis
Susun dari belakang ke depan. Pakai komponen `Layer` dengan `z` dan `fit`:

| Lapis | z kira-kira | fit |
|---|---|---|
| Langit | -1100 | ya |
| Awan | -1000 | ya (geser pelan) |
| Gunung / skyline | -850 s.d. -700 | ya |
| Bukit | -600 | ya |
| Bangunan, pohon | -420 s.d. -350 | ya |
| Lantai | -40 | tidak |
| Properti utama (gerbang) | -140 | tidak |
| Karakter | 0 s.d. +30 | tidak |
| Stiker teks, konfeti | +60 s.d. +120 | tidak |

`fit` membuat lapis jauh tampil sebesar ukuran desain (kompensasi perspektif) tetapi tetap
bergeser lebih lambat saat kamera bergerak — itu parallax. Lapis yang diberi `thickness`
(2–3) menampilkan tepi kertas saat kamera berputar kecil.

Sesuaikan dunia dengan cerita, bukan dengan screenshot. Misalnya cerita di Bogor boleh
memakai gunung dan hujan; cerita di kamar malam memakai dinding biru dan lampu.

### 4. Gerak dan kamera
- Semua animasi digerakkan oleh `useCurrentFrame()` (jangan CSS transition, setTimeout,
  atau Math.random mentah — render paralel akan tidak konsisten). Untuk acak pakai `jitter(seed)`.
- Masuknya objek: `popIn` (spring dengan overshoot) + squash saat mendarat.
- Karakter bergerak "on twos": hitung gerak dengan `hold(frame, 2)`. Garis bergetar lewat
  prop `boil={Math.floor(frame/3)}`.
- Kamera: satu gerakan per beat, dengan ease in-out. Dorong masuk saat emosi, tarik keluar
  saat menjelaskan. Orbit `rotY` ±2–6° terus-menerus supaya kertas terasa tiga dimensi.
- Berjalan ke arah kamera: goyang miring ±4°, loncat kecil, kaki lidi berayun.
- Lip-sync sederhana: `mouthOpen` mengikuti sinus saat jam bicara, diam saat jeda.
- Teks motion graphic (stiker "12 TAHUN") muncul dengan pop, bertahan ≤2 detik, keluar
  sebelum beat berikutnya.

### 5. Sound effect dan musik
Baca `references/sfx-audio.md` sebelum menyusun audio. Intinya:
1. Turunkan daftar SFX dari beat sheet: setiap gerak yang punya "benturan" (mendarat, pop,
   teks muncul, langkah, transisi, konfeti) mendapat satu cue.
2. Cocokkan jenis SFX dengan mood dan karakter (ceria sekolah = pop, boing, ding, bel; tegang =
   hum rendah, tick; lucu = boing, slide whistle).
3. Sinkron ke frame benturan. Whoosh mulai 3–5 frame lebih awal, pop tepat di frame muncul.
4. Variasikan `rate` ±5% untuk bunyi berulang, maksimal 3 bunyi bersamaan, sisakan hening
   sebelum punchline.
5. Mix: VO paling depan, musik di bawah VO dengan ducking, SFX di tengah.
6. Kalau SFX asli belum ada, jalankan `npm run sfx` untuk placeholder sintetis agar video
   langsung bersuara, lalu sarankan pengguna menggantinya dengan SFX berlisensi bernama sama.

### 6. Bangun di Remotion
Starter ada di `assets/starter/` (proyek Remotion lengkap, sudah diuji typecheck dan render).
1. Salin `assets/starter/` ke folder kerja (mis. `/home/claude/<nama-proyek>` atau
   `/mnt/user-data/outputs/<nama-proyek>`), lalu `npm install`.
2. Salin `src/scenes/HermawanIntro.tsx` menjadi scene baru. Ganti hanya bagian "DATA CERITA"
   (`NAME`, `CUES`, `SFX`, dan susunan lapis). Gaya ada di `src/lib/` dan `src/characters/`;
   jangan ubah kecuali pengguna minta gaya baru.
3. Daftarkan komposisi di `src/Root.tsx`.
4. `npm run typecheck` harus bersih.
5. Render still beberapa frame kunci dan **lihat hasilnya** (`npx remotion still ... --frame=N`).
   Periksa: subtitle tidak menimpa wajah/papan nama, tidak ada objek terpotong yang
   mengganggu, karakter jelas di thumbnail, teks terbaca.
6. Render video: `npx remotion render src/index.ts <IdKomposisi> out/video.mp4`.

Catatan lingkungan (penting):
- `--concurrency` tidak boleh melebihi jumlah core CPU. Di sandbox 1 core, pakai `--concurrency=1`.
- Remotion butuh Chrome. Jika unduhan Chrome diblokir, pakai browser yang sudah ada:
  `--browser-executable=<path chrome-headless-shell> --chrome-mode=headless-shell`.
- Kalau render MP4 mustahil di lingkungan ini, serahkan proyek (zip) + perintah render lokal
  dan beri tahu dengan jujur bahwa video belum dirender. Jangan klaim video sudah jadi
  bila belum dirender dan diperiksa.
- Font: starter memakai tumpukan font sistem (`Poppins, Montserrat, Arial Black`). Untuk
  Poppins asli, pasang `@remotion/google-fonts` di mesin yang punya internet.
- Aset audio opsional diatur di `src/config.ts` (`AUDIO.hasVoiceOver`, `hasMusic`, `hasSfx`).
  Set `true` hanya jika file-nya benar-benar ada di `public/`, kalau tidak render gagal.
- Penyimpanan hasil: simpan di `/mnt/user-data/outputs/` dan sajikan file mp4/zip ke pengguna.

### 7. Cek kualitas sebelum menyerahkan
- Gaya: garis tinta konsisten, palet satu keluarga, kepala besar, wajah terbaca.
- Kedalaman: ada parallax nyata saat kamera bergerak; lapis jauh lebih lambat dari lapis dekat.
- Ritme: tidak ada beat yang diam lebih dari 1 detik tanpa gerak; punchline diberi jeda.
- Subtitle: ≤6 kata, aman dari zona UI (jarak bawah ≥ 300 px), cocok dengan VO.
- Audio: tiap SFX punya alasan visual; VO selalu terdengar jelas.
- Orisinalitas: tidak ada karakter/adegan yang meniru screenshot referensi.

## Format balasan ke pengguna
1. Satu-dua kalimat: apa yang dibuat dan asumsi yang diambil.
2. Beat sheet singkat (tabel) bila relevan.
3. Berkas yang diserahkan (mp4 / zip proyek) dan cara menjalankannya.
4. Hal yang perlu disediakan pengguna (VO, musik berlisensi, logo) dan satu tawaran revisi.

## Berkas referensi
- `references/gaya-visual.md` — spesifikasi gaya lengkap (palet, proporsi, ekspresi, dunia, anti-pola).
- `references/sfx-audio.md` — panduan menyesuaikan SFX, timing, mixing, sumber, kode Remotion.
- `references/contoh-hermawan.md` — contoh lengkap video 10 detik perkenalan siswa baru.
- `references/teknik-remotion.md` — teknik 3D kertas, jebakan, dan cara memperluas starter.
- `assets/starter/` — proyek Remotion siap pakai.
