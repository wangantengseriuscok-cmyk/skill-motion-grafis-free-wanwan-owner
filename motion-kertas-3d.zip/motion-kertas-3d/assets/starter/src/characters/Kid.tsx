import React from 'react';
import {INK, UNIFORM} from '../lib/palette';

/**
 * Karakter "kertas" 2D bergaya kartun tebal: kepala bulat besar, garis tinta tebal,
 * wajah minimalis, badan kapsul, kaki lidi. Semua bagian diparameterkan supaya
 * tiap karakter baru cukup ganti props -> gaya tetap konsisten.
 */
export const KID_W = 400;
export const KID_H = 640;

export type Eyes = 'open' | 'happy' | 'surprised' | 'bored';
export type MouthType = 'smile' | 'grin' | 'open' | 'frown' | 'flat';
export type HairStyle = 'rapi' | 'spiky' | 'bob' | 'hijab';
export type Outfit = 'seragam' | 'hoodie' | 'tee';
export type SkinTone = 'light' | 'mid' | 'deep';

const SKIN_MAP: Record<SkinTone, [string, string]> = {
  light: ['#F9D6AE', '#EEB283'],
  mid: ['#F0B782', '#DB9462'],
  deep: ['#BF8156', '#9C6038'],
};

export interface KidProps {
  uid: string; // wajib unik per karakter (id gradient/filter)
  width?: number;
  skinTone?: SkinTone;
  hair?: string;
  hairStyle?: HairStyle;
  outfit?: Outfit;
  outfitColor?: string; // warna hoodie/tee; seragam selalu putih-biru
  pantsColor?: string;
  eyes?: Eyes;
  mouth?: MouthType;
  mouthOpen?: number; // 0..1, animasikan untuk lip-sync
  brow?: number; // -1 marah .. +1 sedih; undefined = tanpa alis
  browLift?: number; // px, negatif = alis naik
  look?: {x: number; y: number}; // -1..1 arah pandang
  blink?: number; // 0..1
  armL?: number; // derajat angkat lengan (sisi kiri layar)
  armR?: number;
  walk?: number; // fase langkah (radian)
  walkAmp?: number; // 0 = diam
  tag?: string; // papan nama kardus
  tagScale?: number;
  backpack?: string;
  squash?: number; // 1 = normal, <1 gepeng, >1 meregang (pivot di kaki)
  tilt?: number; // derajat miring (pivot di kaki)
  boil?: number; // seed filter garis bergetar; undefined = mati
  night?: number; // 0..1 nuansa malam di wajah
}

const Arm: React.FC<{side: 'L' | 'R'; angle: number; sleeve: string; skin: string}> = ({side, angle, sleeve, skin}) => {
  const sx = side === 'L' ? 128 : 272;
  const sy = 376;
  const rot = side === 'L' ? angle : -angle;
  const L = 135;
  return (
    <g transform={`rotate(${rot} ${sx} ${sy})`}>
      <line x1={sx} y1={sy} x2={sx} y2={sy + L} stroke={INK} strokeWidth={36} strokeLinecap="round" />
      <line x1={sx} y1={sy} x2={sx} y2={sy + L} stroke={sleeve} strokeWidth={20} strokeLinecap="round" />
      <circle cx={sx} cy={sy + L + 6} r={19} fill={skin} stroke={INK} strokeWidth={8} />
    </g>
  );
};

const EyeShape: React.FC<{cx: number; cy: number; kind: Eyes; look: {x: number; y: number}; blink: number; night: number}> = ({
  cx,
  cy,
  kind,
  look,
  blink,
  night,
}) => {
  const white = night > 0 ? '#C9D0F4' : '#F6F7FF';
  if (kind === 'happy') {
    return (
      <path
        d={`M ${cx - 32} ${cy + 12} Q ${cx} ${cy - 30} ${cx + 32} ${cy + 12}`}
        fill="none"
        stroke={INK}
        strokeWidth={11}
        strokeLinecap="round"
      />
    );
  }
  if (kind === 'bored') {
    return (
      <g>
        <path d={`M ${cx - 30} ${cy - 2} A 30 24 0 0 0 ${cx + 30} ${cy - 2} Z`} fill={INK} />
        <line x1={cx - 40} y1={cy - 3} x2={cx + 40} y2={cy - 3} stroke={INK} strokeWidth={12} strokeLinecap="round" />
      </g>
    );
  }
  const r = kind === 'surprised' ? 41 : 35;
  const pr = kind === 'surprised' ? 9 : 12;
  const sy = Math.max(0.08, 1 - blink);
  return (
    <g transform={`translate(${cx} ${cy}) scale(1 ${sy}) translate(${-cx} ${-cy})`}>
      <circle cx={cx} cy={cy} r={r} fill={white} stroke={INK} strokeWidth={10} />
      <circle cx={cx + look.x * 12} cy={cy + look.y * 10} r={pr} fill={INK} />
    </g>
  );
};

const Mouth: React.FC<{type: MouthType; open: number; uid: string}> = ({type, open, uid}) => {
  const y = 322;
  if (type === 'smile')
    return <path d={`M 172 ${y} Q 200 ${y + 22} 228 ${y}`} fill="none" stroke={INK} strokeWidth={9} strokeLinecap="round" />;
  if (type === 'frown')
    return <path d={`M 172 ${y + 12} Q 200 ${y - 12} 228 ${y + 12}`} fill="none" stroke={INK} strokeWidth={9} strokeLinecap="round" />;
  if (type === 'flat')
    return <line x1={176} y1={y + 4} x2={224} y2={y + 4} stroke={INK} strokeWidth={9} strokeLinecap="round" />;
  if (type === 'grin') {
    const h = 14 + 26 * open;
    const d = `M 154 ${y - 12} L 246 ${y - 12} Q 240 ${y - 12 + h} 200 ${y - 12 + h} Q 160 ${y - 12 + h} 154 ${y - 12} Z`;
    return (
      <g>
        <defs>
          <clipPath id={`mouth-grin-${uid}`}>
            <path d={d} />
          </clipPath>
        </defs>
        <path d={d} fill="#4A1A25" />
        <g clipPath={`url(#mouth-grin-${uid})`}>
          <rect x={150} y={y - 14} width={100} height={11} fill="#fff" />
          <ellipse cx={200} cy={y - 12 + h} rx={24} ry={h * 0.35} fill="#C8505F" />
        </g>
        <path d={d} fill="none" stroke={INK} strokeWidth={8} strokeLinejoin="round" />
      </g>
    );
  }
  const ry = 8 + 20 * open;
  return <ellipse cx={200} cy={y + 2} rx={22 + 6 * open} ry={ry} fill="#4A1A25" stroke={INK} strokeWidth={8} />;
};

const Hair: React.FC<{style: HairStyle; color: string}> = ({style, color}) => {
  const common = {fill: color, stroke: INK, strokeWidth: 10, strokeLinejoin: 'round' as const};
  if (style === 'hijab') return null; // digambar terpisah
  const cap =
    'M 62 174 A 143 143 0 0 1 338 174 L 334 174 L 318 200 L 290 178 L 262 208 L 232 180 L 200 210 L 168 182 L 138 208 L 110 178 L 84 202 L 66 174 Z';
  return (
    <g>
      <path d={cap} {...common} />
      {style === 'bob' && (
        <g>
          <path d="M 66 182 C 40 232 44 292 88 298 C 100 270 100 230 94 198 Z" {...common} />
          <path d="M 334 182 C 360 232 356 292 312 298 C 300 270 300 230 306 198 Z" {...common} />
        </g>
      )}
    </g>
  );
};

const HairBack: React.FC<{style: HairStyle; color: string}> = ({style, color}) => {
  const common = {fill: color, stroke: INK, strokeWidth: 10, strokeLinejoin: 'round' as const};
  if (style === 'spiky')
    return (
      <g>
        <path d="M 138 104 L 108 46 L 182 80 Z" {...common} />
        <path d="M 182 78 L 200 16 L 232 80 Z" {...common} />
        <path d="M 238 84 L 296 40 L 286 112 Z" {...common} />
      </g>
    );
  if (style === 'rapi') return <path d="M 200 84 Q 212 26 256 38 Q 234 56 238 90 Z" {...common} />;
  return null;
};

export const Kid: React.FC<KidProps> = ({
  uid,
  width = 400,
  skinTone = 'light',
  hair = '#1E1414',
  hairStyle = 'rapi',
  outfit = 'seragam',
  outfitColor = '#1E9E9A',
  pantsColor = UNIFORM.navy,
  eyes = 'open',
  mouth = 'smile',
  mouthOpen = 0.5,
  brow,
  browLift = 0,
  look = {x: 0, y: 0},
  blink = 0,
  armL = 10,
  armR = 10,
  walk = 0,
  walkAmp = 0,
  tag,
  tagScale = 1,
  backpack,
  squash = 1,
  tilt = 0,
  boil,
  night = 0,
}) => {
  const [skinA, skinB] = SKIN_MAP[skinTone];
  const shirt = outfit === 'seragam' ? UNIFORM.shirt : outfitColor;
  const legL = Math.sin(walk) * 26 * walkAmp;
  const legR = -Math.sin(walk) * 26 * walkAmp;
  const eyeY = 255;
  const bodyPath = 'M 122 335 H 278 V 475 Q 278 547 200 547 Q 122 547 122 475 Z';

  const browEl = (side: 'L' | 'R') => {
    if (brow === undefined) return null;
    const dir = side === 'L' ? 1 : -1;
    const ox = 200 - dir * 90;
    const ix = 200 - dir * 22;
    const by = 212 + browLift;
    return (
      <line
        x1={ox}
        y1={by + brow * 8}
        x2={ix}
        y2={by - brow * 16}
        stroke={INK}
        strokeWidth={13}
        strokeLinecap="round"
      />
    );
  };

  return (
    <svg
      viewBox={`0 0 ${KID_W} ${KID_H}`}
      width={width}
      height={(width * KID_H) / KID_W}
      style={{overflow: 'visible', filter: boil !== undefined ? `url(#boil-${uid})` : undefined}}
    >
      <defs>
        <linearGradient id={`skin-${uid}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor={skinA} />
          <stop offset="1" stopColor={skinB} />
        </linearGradient>
        <radialGradient id={`night-${uid}`} cx="50%" cy="25%" r="80%">
          <stop offset="0.35" stopColor="#6C74C8" stopOpacity={0} />
          <stop offset="1" stopColor="#6C74C8" stopOpacity={0.55 * night} />
        </radialGradient>
        <clipPath id={`body-${uid}`}>
          <path d={bodyPath} />
        </clipPath>
        <clipPath id={`head-${uid}`}>
          <circle cx={200} cy={210} r={140} />
        </clipPath>
        {boil !== undefined && (
          <filter id={`boil-${uid}`} x="-5%" y="-5%" width="110%" height="110%">
            <feTurbulence type="fractalNoise" baseFrequency="0.018" numOctaves={2} seed={Math.floor(boil) % 12} result="n" />
            <feDisplacementMap in="SourceGraphic" in2="n" scale={5} xChannelSelector="R" yChannelSelector="G" />
          </filter>
        )}
      </defs>

      <g transform={`rotate(${tilt} 200 612) translate(200 612) scale(${1 / Math.sqrt(squash)} ${squash}) translate(-200 -612)`}>
        {/* Ransel (di belakang badan) */}
        {backpack && (
          <rect x={102} y={352} width={196} height={186} rx={62} fill={backpack} stroke={INK} strokeWidth={10} />
        )}

        {/* Kaki lidi */}
        {[
          {x: 172, a: legL},
          {x: 228, a: legR},
        ].map((l, i) => (
          <g key={i} transform={`rotate(${l.a} ${l.x} 540)`}>
            <line x1={l.x} y1={540} x2={l.x} y2={598} stroke={INK} strokeWidth={12} strokeLinecap="round" />
            <ellipse cx={l.x + (i === 0 ? -8 : 8)} cy={604} rx={24} ry={10} fill={INK} />
          </g>
        ))}

        {/* Badan kapsul */}
        <path d={bodyPath} fill={shirt} />
        {outfit === 'seragam' && (
          <g clipPath={`url(#body-${uid})`}>
            <rect x={110} y={468} width={180} height={90} fill={pantsColor} />
            <line x1={110} y1={468} x2={290} y2={468} stroke={INK} strokeWidth={6} />
          </g>
        )}
        <path d={bodyPath} fill="none" stroke={INK} strokeWidth={11} strokeLinejoin="round" />

        {/* Detail baju */}
        {outfit === 'seragam' && (
          <g>
            <path d="M 156 338 L 200 392 L 244 338" fill="#fff" stroke={INK} strokeWidth={8} strokeLinejoin="round" />
            <path d="M 200 392 L 186 414 L 200 460 L 214 414 Z" fill={pantsColor} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
          </g>
        )}
        {outfit === 'hoodie' && (
          <g>
            <path d="M 150 345 Q 200 410 250 345" fill="none" stroke={INK} strokeWidth={9} strokeLinecap="round" />
            <line x1={184} y1={392} x2={184} y2={440} stroke="#fff" strokeWidth={8} strokeLinecap="round" />
            <line x1={216} y1={392} x2={216} y2={440} stroke="#fff" strokeWidth={8} strokeLinecap="round" />
          </g>
        )}
        {outfit === 'tee' && (
          <path d="M 164 340 Q 200 376 236 340" fill="none" stroke={INK} strokeWidth={9} strokeLinecap="round" />
        )}

        {/* Tali ransel */}
        {backpack && (
          <g fill="none" stroke={INK} strokeWidth={9} strokeLinecap="round">
            <path d="M 150 340 Q 144 410 160 470" />
            <path d="M 250 340 Q 256 410 240 470" />
          </g>
        )}

        {/* Papan nama kardus */}
        {tag && (
          <g transform={`translate(200 436) scale(${tagScale}) translate(-200 -436)`}>
            <path d="M 166 344 L 192 424 M 234 344 L 208 424" stroke={INK} strokeWidth={5} fill="none" strokeLinecap="round" />
            <g transform="rotate(-4 200 456)">
              <rect x={146} y={424} width={108} height={58} rx={6} fill={UNIFORM.tagCard} stroke={INK} strokeWidth={6} />
              <text
                x={200}
                y={461}
                textAnchor="middle"
                fontFamily='"Poppins","Montserrat","Arial Black",sans-serif'
                fontWeight={900}
                fontSize={17}
                fill={INK}
                textLength={90}
                lengthAdjust="spacingAndGlyphs"
              >
                {tag}
              </text>
            </g>
          </g>
        )}

        {/* Lengan */}
        <Arm side="L" angle={armL} sleeve={shirt} skin={skinA} />
        <Arm side="R" angle={armR} sleeve={shirt} skin={skinA} />

        {/* Rambut belakang (jambul) */}
        <HairBack style={hairStyle} color={hair} />

        {/* Kepala */}
        <circle cx={200} cy={210} r={140} fill={`url(#skin-${uid})`} />
        {night > 0 && <circle cx={200} cy={210} r={140} fill={`url(#night-${uid})`} />}
        <g clipPath={`url(#head-${uid})`}>
          <ellipse cx={128} cy={300} rx={20} ry={12} fill="#F0847A" opacity={0.35} />
          <ellipse cx={272} cy={300} rx={20} ry={12} fill="#F0847A" opacity={0.35} />
        </g>
        <circle cx={200} cy={210} r={140} fill="none" stroke={INK} strokeWidth={12} />

        {/* Rambut / hijab */}
        <Hair style={hairStyle} color={hair} />
        {hairStyle === 'hijab' && (
          <path
            fillRule="evenodd"
            d="M 200 58 C 290 58 352 118 352 214 C 352 300 322 352 270 384 L 130 384 C 78 352 48 300 48 214 C 48 118 110 58 200 58 Z M 200 168 C 140 168 96 206 96 262 C 96 316 140 350 200 350 C 260 350 304 316 304 262 C 304 206 260 168 200 168 Z"
            fill={hair}
            stroke={INK}
            strokeWidth={10}
            strokeLinejoin="round"
          />
        )}

        {/* Wajah */}
        {browEl('L')}
        {browEl('R')}
        <EyeShape cx={148} cy={eyeY} kind={eyes} look={look} blink={blink} night={night} />
        <EyeShape cx={252} cy={eyeY} kind={eyes} look={look} blink={blink} night={night} />
        <Mouth type={mouth} open={mouthOpen} uid={uid} />
      </g>
    </svg>
  );
};
