import React from 'react';
import {INK, DAY} from '../lib/palette';

const line = {stroke: INK, strokeWidth: 5, strokeLinejoin: 'round' as const, strokeLinecap: 'round' as const};
const FONT = '"Poppins","Montserrat","Arial Black",sans-serif';

export const SkyGradient: React.FC = () => (
  <div style={{width: '100%', height: '100%', background: `linear-gradient(180deg, ${DAY.skyTop} 0%, ${DAY.skyBottom} 70%, ${DAY.haze} 100%)`}} />
);

export const Cloud: React.FC<{w?: number}> = ({w = 420}) => (
  <svg viewBox="0 0 420 180" width={w} height={(w * 180) / 420} style={{overflow: 'visible'}}>
    <path
      d="M 40 150 C 0 150 0 100 44 98 C 40 50 110 34 140 66 C 160 20 240 20 258 70 C 300 44 360 70 346 108 C 396 108 404 150 360 150 Z"
      fill="#fff"
      stroke="#9FC3EA"
      strokeWidth={4}
      strokeLinejoin="round"
    />
  </svg>
);

/** Gunung segitiga bergaya kertas: dua sisi (terang/gelap) + garis tinta tipis. */
export const Mountain: React.FC<{w?: number; h?: number; color?: string; snow?: boolean}> = ({
  w = 1200,
  h = 760,
  color = DAY.mountainFar,
  snow = false,
}) => (
  <svg viewBox="0 0 1200 760" width={w} height={h} preserveAspectRatio="none" style={{overflow: 'visible'}}>
    <polygon points="0,760 560,20 1200,760" fill={color} />
    <polygon points="560,20 1200,760 700,760" fill="rgba(30,40,90,0.18)" />
    {snow && <polygon points="560,20 470,150 540,130 580,170 640,120 690,150" fill="#F2F7FF" />}
    <polyline points="0,760 560,20 1200,760" fill="none" stroke="#2A3A66" strokeWidth={3} opacity={0.7} strokeLinejoin="round" />
  </svg>
);

export const Hill: React.FC<{w?: number; h?: number; color?: string}> = ({w = 2000, h = 520, color = DAY.grass}) => (
  <svg viewBox="0 0 2000 520" width={w} height={h} preserveAspectRatio="none" style={{overflow: 'visible'}}>
    <path d="M 0 520 L 0 200 C 300 60 700 40 1000 120 C 1400 220 1700 60 2000 140 L 2000 520 Z" fill={color} />
    <path d="M 0 200 C 300 60 700 40 1000 120 C 1400 220 1700 60 2000 140" fill="none" stroke="#1F5A1B" strokeWidth={4} opacity={0.6} />
  </svg>
);

export const PineTree: React.FC<{w?: number; color?: string}> = ({w = 220, color = DAY.pine}) => (
  <svg viewBox="0 0 220 340" width={w} height={(w * 340) / 220} style={{overflow: 'visible'}}>
    <rect x={95} y={250} width={30} height={84} rx={4} fill={DAY.trunk} {...line} />
    <polygon points="110,6 190,120 30,120" fill={color} {...line} />
    <polygon points="110,66 205,190 15,190" fill={color} {...line} />
    <polygon points="110,126 214,262 6,262" fill={color} {...line} />
  </svg>
);

/** Rumah warga: dinding krem, atap genteng terakota, pintu & jendela. */
export const House: React.FC<{w?: number; wall?: string; roof?: string}> = ({w = 420, wall = '#FFE7B8', roof = '#D4552F'}) => (
  <svg viewBox="0 0 420 360" width={w} height={(w * 360) / 420} style={{overflow: 'visible'}}>
    <rect x={40} y={140} width={340} height={210} fill={wall} {...line} />
    <polygon points="14,150 210,20 406,150" fill={roof} {...line} />
    <rect x={170} y={230} width={80} height={120} rx={6} fill="#8A5A2B" {...line} />
    <circle cx={238} cy={292} r={5} fill="#FFD84D" />
    <rect x={64} y={190} width={80} height={80} fill="#BFE3FF" {...line} />
    <line x1={104} y1={190} x2={104} y2={270} {...line} strokeWidth={4} />
    <line x1={64} y1={230} x2={144} y2={230} {...line} strokeWidth={4} />
    <rect x={276} y={190} width={80} height={80} fill="#BFE3FF" {...line} />
    <line x1={316} y1={190} x2={316} y2={270} {...line} strokeWidth={4} />
    <line x1={276} y1={230} x2={356} y2={230} {...line} strokeWidth={4} />
  </svg>
);

/** Gerbang sekolah: dua pilar, papan nama di atas, pagar di sisi. */
export const SchoolGate: React.FC<{w?: number; name: string}> = ({w = 900, name}) => (
  <svg viewBox="0 0 900 560" width={w} height={(w * 560) / 900} style={{overflow: 'visible'}}>
    {/* pagar */}
    {Array.from({length: 7}).map((_, i) => (
      <g key={i}>
        <rect x={20 + i * 36} y={330} width={14} height={190} rx={4} fill="#F2F2F8" {...line} strokeWidth={4} />
        <rect x={650 + i * 36} y={330} width={14} height={190} rx={4} fill="#F2F2F8" {...line} strokeWidth={4} />
      </g>
    ))}
    <rect x={10} y={380} width={880} height={14} fill="#F2F2F8" {...line} strokeWidth={4} />
    {/* pilar */}
    <rect x={250} y={200} width={90} height={330} fill="#E9DCC3" {...line} />
    <rect x={560} y={200} width={90} height={330} fill="#E9DCC3" {...line} />
    <rect x={238} y={180} width={114} height={36} rx={6} fill="#C9B48A" {...line} />
    <rect x={548} y={180} width={114} height={36} rx={6} fill="#C9B48A" {...line} />
    {/* papan nama */}
    <rect x={190} y={36} width={520} height={150} rx={22} fill="#243A73" {...line} />
    <rect x={206} y={52} width={488} height={118} rx={14} fill="none" stroke="#FFD84D" strokeWidth={4} />
    <text x={450} y={100} textAnchor="middle" fontFamily={FONT} fontWeight={900} fontSize={44} fill="#fff">
      {name.split('|')[0]}
    </text>
    <text x={450} y={150} textAnchor="middle" fontFamily={FONT} fontWeight={900} fontSize={44} fill="#FFD84D">
      {name.split('|')[1] ?? ''}
    </text>
  </svg>
);

/** Spanduk gantung berayun. Tali memanjang ke atas (keluar frame) lewat ropeLen. */
export const Banner: React.FC<{w?: number; text: string; sub?: string; ropeLen?: number}> = ({w = 700, text, sub, ropeLen = 40}) => (
  <svg viewBox="0 0 700 300" width={w} height={(w * 300) / 700} style={{overflow: 'visible'}}>
    <line x1={120} y1={60 - ropeLen} x2={120} y2={62} {...line} />
    <line x1={580} y1={60 - ropeLen} x2={580} y2={62} {...line} />
    <path d="M 40 60 L 660 60 L 640 160 L 660 260 L 40 260 L 60 160 Z" fill="#FFB02E" {...line} />
    <text x={350} y={170} textAnchor="middle" fontFamily={FONT} fontWeight={900} fontSize={104} fill={INK}>
      {text}
    </text>
    {sub && (
      <text x={350} y={228} textAnchor="middle" fontFamily={FONT} fontWeight={800} fontSize={34} fill="#fff">
        {sub}
      </text>
    )}
  </svg>
);

/** Lembar konfeti kertas: dipakai dengan rotX/rotY berputar di Layer supaya terasa 3D. */
export const ConfettiPiece: React.FC<{color: string; w?: number; h?: number}> = ({color, w = 34, h = 54}) => (
  <div style={{width: w, height: h, background: color, border: `4px solid ${INK}`, borderRadius: 6}} />
);

/** Lantai kertas: rumput + jalan setapak. Datar, kedalaman datang dari parallax kamera. */
export const GroundPlane: React.FC = () => (
  <div
    style={{
      width: '100%',
      height: '100%',
      background: `linear-gradient(180deg, ${DAY.grassDark} 0%, ${DAY.grass} 12%, #5DBB45 100%)`,
      position: 'relative',
      overflow: 'hidden',
      borderTop: `6px solid ${INK}`,
    }}
  >
    <div
      style={{
        position: 'absolute',
        left: 0,
        right: 0,
        top: 90,
        height: 520,
        background: `linear-gradient(180deg, #CFA56D, ${DAY.path})`,
        borderTop: `6px solid ${INK}`,
        borderBottom: `6px solid ${INK}`,
      }}
    />
  </div>
);
