import React from 'react';
import {AbsoluteFill, Audio, staticFile, useCurrentFrame, useVideoConfig} from 'remotion';
import {AUDIO} from '../config';
import {Kid} from '../characters/Kid';
import {Layer, World, Cam} from '../lib/World3D';
import {GroundShadow, PaperGrain, PaperSign, Vignette} from '../lib/Paper';
import {Subtitle, Cue} from '../lib/Subtitle';
import {Music, SfxCue, SfxTrack} from '../lib/Sfx';
import {hold, jitter, popIn, ramp, wobble} from '../lib/motion';
import {DAY} from '../lib/palette';
import {Banner, Cloud, ConfettiPiece, GroundPlane, Hill, House, Mountain, PineTree, SchoolGate, SkyGradient} from '../props/Scenery';

/* ------------------------------------------------------------------ *
 *  DATA CERITA — ubah bagian ini untuk cerita lain, jangan sentuh gaya
 * ------------------------------------------------------------------ */
const NAME = 'HERMAWAN';
const SCHOOL_SIGN = 'SMP YKTB|KOTA BOGOR';

// Waktu dalam detik. Kamera, SFX, dan subtitle semua mengacu ke sini.
const CUES: Cue[] = [
  {from: 0.2, to: 1.95, text: 'Halo semuanya!'},
  {from: 2.0, to: 4.35, text: 'Aku Hermawan, umur 12 tahun', emphasis: ['Hermawan', '12']},
  {from: 4.4, to: 6.0, text: 'Aku tinggal di Menteng,', emphasis: ['Menteng']},
  {from: 6.0, to: 8.0, text: 'siswa baru SMP YKTB Kota Bogor', emphasis: ['YKTB']},
  {from: 8.0, to: 9.95, text: 'Siap MPLS 2025! Salam kenal!', emphasis: ['MPLS', '2025']},
];
const SPEECH: Array<[number, number]> = CUES.map((c) => [c.from, c.to]);

const SFX: SfxCue[] = [
  {at: 0.3, file: 'whoosh.wav', volume: 0.5, lead: 0.12},
  {at: 0.55, file: 'pop.wav', volume: 0.7},
  {at: 0.6, file: 'boing.wav', volume: 0.35, rate: 1.1},
  {at: 2.0, file: 'whoosh.wav', volume: 0.4, rate: 1.15, lead: 0.1},
  {at: 2.35, file: 'pop.wav', volume: 0.6, rate: 1.2},
  {at: 2.95, file: 'sparkle.wav', volume: 0.5},
  {at: 4.5, file: 'step.wav', volume: 0.5, rate: 0.95},
  {at: 4.85, file: 'step.wav', volume: 0.5, rate: 1.05},
  {at: 5.2, file: 'step.wav', volume: 0.5, rate: 0.97},
  {at: 5.55, file: 'step.wav', volume: 0.5, rate: 1.06},
  {at: 5.9, file: 'step.wav', volume: 0.5, rate: 0.96},
  {at: 6.25, file: 'step.wav', volume: 0.4, rate: 1.02},
  {at: 6.1, file: 'whoosh.wav', volume: 0.3, rate: 0.8, lead: 0.2},
  {at: 7.4, file: 'bell.wav', volume: 0.45},
  {at: 8.0, file: 'pop.wav', volume: 0.6, rate: 1.0},
  {at: 8.12, file: 'pop.wav', volume: 0.6, rate: 1.15},
  {at: 8.3, file: 'whoosh.wav', volume: 0.35, rate: 0.9},
  {at: 8.45, file: 'confetti.wav', volume: 0.6},
  {at: 9.65, file: 'sparkle.wav', volume: 0.5, rate: 1.1},
];

/* ------------------------------ kamera ------------------------------ */
const camAt = (f: number): Cam => {
  // A 0-60: tarik masuk dari jauh. B 60-132: dorong ke wajah. C 132-225: truck mengikuti jalan.
  // D 225-300: dolly out pelan sambil orbit kecil.
  let z = ramp(f, 0, 60, -140, 70);
  z = f >= 60 ? ramp(f, 60, 118, 70, 300) : z;
  z = f >= 132 ? ramp(f, 132, 180, 300, 40) : z;
  z = f >= 225 ? ramp(f, 225, 300, 40, -40) : z;
  const y = f < 132 ? ramp(f, 60, 118, 0, 130) : ramp(f, 132, 180, 130, 0);
  const x = ramp(f, 136, 232, 0, 820, (t) => t * t * (3 - 2 * t));
  const rotY = ramp(f, 0, 60, -7, -3) + (f >= 60 ? ramp(f, 60, 130, 0, 4) : 0) + (f >= 132 ? ramp(f, 132, 232, 0, -5) : 0) + (f >= 232 ? wobble(f, 150, 2.5) : 0);
  const rotX = ramp(f, 0, 60, 3, 0);
  return {x, y, z, rotX, rotY};
};

export const HermawanIntro: React.FC = () => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const cam = camAt(frame);
  const f2 = hold(frame, 2); // gerak karakter "on twos" -> rasa gambar tangan
  const boilSeed = Math.floor(frame / 3);

  // ---- Hermawan ----
  const enter = popIn(frame, fps, 6); // loncat masuk dari bawah
  const enterY = (1 - Math.min(enter, 1)) * 900;
  const landSquash = frame < 22 ? 1 + (1 - enter) * 0.25 : 1 - Math.max(0, 0.12 * (1 - ramp(frame, 17, 27, 0, 1)));
  const walking = frame >= 132 && frame < 236;
  const walkPhase = walking ? f2 * 0.42 : 0;
  const hx = ramp(frame, 132, 232, 0, 820, (u) => u * u * (3 - 2 * u));
  const hop = walking ? -Math.abs(Math.sin(walkPhase)) * 28 : 0;
  const talking = SPEECH.some(([a, b]) => t >= a && t <= b);
  const mouthOpen = talking ? 0.25 + 0.75 * Math.abs(Math.sin(f2 * 0.95)) : 0.1;
  const wave = frame < 70 ? 118 + wobble(f2, 10, 22) : frame >= 232 ? 125 + wobble(f2, 9, 24) : 14;
  const tagPop = popIn(frame, fps, 70);
  const blink = frame % 84 > 80 ? 1 : 0;
  const heroY = 205 + enterY + hop;
  const eyes = frame > 236 || frame < 60 ? 'happy' : 'open';
  const heroX = hx;

  // ---- stiker 12 TAHUN ----
  const signPop = popIn(frame, fps, 88);
  const signShow = frame >= 88 && frame < 134;
  const signOut = ramp(frame, 126, 134, 1, 0);

  // ---- teman ----
  const friend1 = popIn(frame, fps, 240);
  const friend2 = popIn(frame, fps, 247);

  // ---- konfeti ----
  const confetti = frame >= 252 ? Array.from({length: 26}) : [];
  const COLORS = ['#FF5A5F', '#FFD84D', '#3DDC97', '#4DA3FF', '#B26BFF'];

  const cloudDrift = frame * 0.5;

  return (
    <AbsoluteFill style={{background: '#9ED2FF'}}>
      <World cam={cam}>
        {/* langit & awan */}
        <Layer z={-1100} fit w={2800} h={3200} y={0}>
          <SkyGradient />
        </Layer>
        <Layer z={-1000} fit w={420} h={180} x={-260 + cloudDrift} y={-640}><Cloud w={420} /></Layer>
        <Layer z={-1000} fit w={420} h={180} x={300 + cloudDrift * 0.7} y={-420}><Cloud w={340} /></Layer>
        <Layer z={-1000} fit w={420} h={180} x={900 + cloudDrift * 0.6} y={-560}><Cloud w={380} /></Layer>

        {/* gunung (Gunung Salak ala kertas) */}
        <Layer z={-850} fit w={1500} h={900} x={160} y={-120} blur={cam.z > 200 ? 2 : 0}>
          <Mountain w={1500} h={900} color={DAY.mountainFar} />
        </Layer>
        <Layer z={-780} fit w={1100} h={680} x={-520} y={-20}>
          <Mountain w={1100} h={680} color={DAY.mountainNear} />
        </Layer>
        <Layer z={-780} fit w={1100} h={680} x={1250} y={-20}>
          <Mountain w={1100} h={680} color={DAY.mountainNear} />
        </Layer>

        {/* bukit */}
        <Layer z={-600} fit w={3600} h={560} x={300} y={150}>
          <Hill w={3600} h={560} color="#5DB64A" />
        </Layer>

        {/* pemukiman Menteng */}
        <Layer z={-420} fit w={420} h={360} x={-380} y={235}><House w={420} /></Layer>
        <Layer z={-420} fit w={420} h={360} x={140} y={255}><House w={340} wall="#CFE9FF" roof="#7A4DB3" /></Layer>
        <Layer z={-380} fit w={220} h={340} x={-120} y={270}><PineTree w={180} /></Layer>
        <Layer z={-380} fit w={220} h={340} x={420} y={280}><PineTree w={200} /></Layer>

        {/* lantai kertas (miring => kedalaman) */}
        <Layer z={-40} w={6000} h={1100} x={400} y={920}>
          <GroundPlane />
        </Layer>

        {/* gerbang sekolah */}
        <Layer z={-140} w={900} h={560} x={820} y={190} thickness={2}>
          <SchoolGate w={900} name={SCHOOL_SIGN} />
        </Layer>
        <Layer z={-110} w={700} h={300} x={820} y={-330} rotZ={wobble(frame, 70, 2.2)} origin="50% 0%" thickness={2}>
          <Banner w={700} text="MPLS 2025" sub="Selamat datang!" ropeLen={760} />
        </Layer>
        <Layer z={-380} fit w={220} h={340} x={1260} y={270}><PineTree w={200} /></Layer>
        <Layer z={-380} fit w={220} h={340} x={1500} y={290}><PineTree w={180} /></Layer>

        {/* teman-teman */}
        <Layer z={30} w={420} h={672} x={heroX + 300} y={250 + (1 - Math.min(friend1, 1)) * 1400} thickness={2}>
          <div style={{position: 'absolute', left: 60, top: 640}}><GroundShadow w={260} /></div>
          <Kid uid="f1" width={420} skinTone="mid" hairStyle="hijab" hair="#F4F4FA" eyes="happy" mouth="grin" mouthOpen={0.7} armL={110 + wobble(f2, 11, 20)} armR={14} backpack="#E4572E" boil={boilSeed} />
        </Layer>
        <Layer z={20} w={420} h={672} x={heroX - 300} y={270 + (1 - Math.min(friend2, 1)) * 1400} thickness={2}>
          <div style={{position: 'absolute', left: 60, top: 640}}><GroundShadow w={260} /></div>
          <Kid uid="f2" width={420} skinTone="deep" hairStyle="spiky" hair="#17120F" eyes="happy" mouth="grin" mouthOpen={0.6} armL={14} armR={115 + wobble(f2, 9, 22)} backpack="#3A7BD5" boil={boilSeed} />
        </Layer>

        {/* HERMAWAN */}
        <Layer z={0} w={625} h={1000} x={heroX} y={heroY} thickness={3}>
          <div style={{position: 'absolute', left: 150, top: 960 - hop}}><GroundShadow w={340} squash={1 + hop / 200} /></div>
          <Kid
            uid="hermawan"
            width={625}
            skinTone="light"
            hairStyle="rapi"
            outfit="seragam"
            eyes={eyes}
            mouth={talking ? 'grin' : 'smile'}
            mouthOpen={mouthOpen}
            blink={blink}
            look={{x: Math.sin(frame / 20) * 0.3, y: 0}}
            armL={wave}
            armR={walking ? 14 + Math.sin(walkPhase + Math.PI) * 18 : 14}
            walk={walkPhase}
            walkAmp={walking ? 1 : 0}
            tag={NAME}
            tagScale={frame >= 70 ? tagPop : 0}
            backpack="#E4572E"
            squash={landSquash}
            tilt={walking ? Math.sin(walkPhase) * 4 : wobble(f2, 40, 1.5)}
            boil={boilSeed}
          />
        </Layer>

        {/* stiker umur */}
        {signShow && (
          <Layer z={120} w={520} h={170} x={cam.x + 30} y={-370} rotZ={4} opacity={signOut}>
            <PaperSign text="12 TAHUN" size={72} rotate={-5} scale={Math.min(signPop, 1.15)} />
          </Layer>
        )}

        {/* konfeti kertas 3D */}
        {confetti.map((_, i) => {
          const fr = frame - 252;
          const sx = (jitter(i + 1) - 0.5) * 1100;
          const y0 = -1150 - jitter(i + 40) * 500;
          const speed = 14 + jitter(i + 9) * 12;
          const yy = y0 + fr * speed;
          return (
            <Layer
              key={i}
              z={-60 + jitter(i + 5) * 260}
              w={34}
              h={54}
              x={cam.x + sx + Math.sin(fr / 9 + i) * 40}
              y={yy}
              rotX={fr * (6 + jitter(i + 2) * 8)}
              rotY={fr * (5 + jitter(i + 3) * 9)}
              rotZ={fr * 3 + i * 40}
            >
              <ConfettiPiece color={COLORS[i % COLORS.length]} />
            </Layer>
          );
        })}
      </World>

      <Vignette strength={0.3} />
      <PaperGrain />
      <Subtitle cues={CUES} bottom={300} />

      {AUDIO.hasVoiceOver && <Audio src={staticFile('audio/vo.mp3')} />}
      {AUDIO.hasMusic && <Music file="audio/music.mp3" speech={SPEECH} />}
      {AUDIO.hasSfx && <SfxTrack cues={SFX} />}
    </AbsoluteFill>
  );
};
