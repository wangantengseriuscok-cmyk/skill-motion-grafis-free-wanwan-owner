import React from 'react';
import {AbsoluteFill} from 'remotion';
import {Kid, KidProps} from '../characters/Kid';

const ROWS: Array<Partial<KidProps> & {uid: string}> = [
  {uid: 'a', eyes: 'happy', mouth: 'grin', tag: 'NAMA', backpack: '#E4572E'},
  {uid: 'b', eyes: 'surprised', mouth: 'open', mouthOpen: 0.8, brow: 0.6, browLift: -14, hairStyle: 'spiky', outfit: 'hoodie'},
  {uid: 'c', eyes: 'bored', mouth: 'frown', brow: -0.8, hairStyle: 'bob', hair: '#5A3A22', outfit: 'tee', outfitColor: '#9B5DE5', night: 1},
  {uid: 'd', eyes: 'open', mouth: 'smile', hairStyle: 'hijab', hair: '#F4F4FA', skinTone: 'mid'},
  {uid: 'e', eyes: 'open', mouth: 'flat', skinTone: 'deep', hairStyle: 'spiky', hair: '#17120F', outfit: 'hoodie', outfitColor: '#1E9E9A', armL: 120},
];

export const CharacterSheet: React.FC = () => (
  <AbsoluteFill style={{background: '#CFE6FF', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', padding: 30}}>
    {ROWS.map((r) => (
      <Kid key={r.uid} width={290} {...r} />
    ))}
  </AbsoluteFill>
);
