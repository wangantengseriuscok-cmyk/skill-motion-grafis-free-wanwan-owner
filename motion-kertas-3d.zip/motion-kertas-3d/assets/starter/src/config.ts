// Pengaturan global video. Ubah di sini, jangan hardcode di scene.
export const VIDEO = {
  width: 1080,
  height: 1920, // 9:16 untuk Reels / TikTok / Shorts
  fps: 30,
  durationInSeconds: 10,
};

// Aset audio opsional. Set true HANYA jika filenya sudah ada di /public.
export const AUDIO = {
  hasVoiceOver: false, // public/audio/vo.mp3
  hasMusic: false, // public/audio/music.mp3
  hasSfx: true, // public/sfx/*.wav (jalankan `npm run sfx` untuk placeholder)
};
