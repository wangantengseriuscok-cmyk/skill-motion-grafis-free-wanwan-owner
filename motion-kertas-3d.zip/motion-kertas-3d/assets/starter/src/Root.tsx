import React from 'react';
import {Composition} from 'remotion';
import {VIDEO} from './config';
import {HermawanIntro} from './scenes/HermawanIntro';
import {CharacterSheet} from './scenes/CharacterSheet';

export const RemotionRoot: React.FC = () => (
  <>
    <Composition
      id="HermawanIntro"
      component={HermawanIntro}
      durationInFrames={VIDEO.durationInSeconds * VIDEO.fps}
      fps={VIDEO.fps}
      width={VIDEO.width}
      height={VIDEO.height}
    />
    {/* Lembar karakter: cek konsistensi gaya sebelum membuat scene panjang */}
    <Composition id="CharacterSheet" component={CharacterSheet} durationInFrames={30} fps={VIDEO.fps} width={1600} height={1000} />
  </>
);
