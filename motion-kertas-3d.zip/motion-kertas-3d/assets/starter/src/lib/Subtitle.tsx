import React from 'react';
import {AbsoluteFill, useCurrentFrame, useVideoConfig} from 'remotion';
import {popIn} from './motion';

export interface Cue {
  from: number; // detik
  to: number; // detik
  text: string;
  /** Kata yang diberi warna aksen (cocokkan persis, tanpa tanda baca). */
  emphasis?: string[];
}

const ACCENT = '#FFD84D';

/**
 * Subtitle gaya short-form: putih tebal + kontur hitam, tengah-bawah,
 * 1-6 kata per kemunculan, muncul dengan "pop" kecil.
 */
export const Subtitle: React.FC<{cues: Cue[]; bottom?: number; size?: number}> = ({
  cues,
  bottom = 330,
  size = 70,
}) => {
  const frame = useCurrentFrame();
  const {fps} = useVideoConfig();
  const t = frame / fps;
  const cue = cues.find((c) => t >= c.from && t < c.to);
  if (!cue) return null;
  const local = frame - Math.round(cue.from * fps);
  const s = 0.82 + 0.18 * popIn(local, fps);
  const words = cue.text.split(' ');
  return (
    <AbsoluteFill style={{justifyContent: 'flex-end', alignItems: 'center', paddingBottom: bottom}}>
      <div
        style={{
          maxWidth: 940,
          textAlign: 'center',
          fontFamily: '"Poppins","Montserrat","Arial Black",sans-serif',
          fontWeight: 800,
          fontSize: size,
          lineHeight: 1.12,
          color: '#fff',
          WebkitTextStroke: `${size * 0.17}px #0B0818`,
          paintOrder: 'stroke fill',
          textShadow: '0 7px 0 rgba(0,0,0,0.35)',
          transform: `scale(${s})`,
        }}
      >
        {words.map((w, i) => {
          const clean = w.replace(/[^\p{L}\p{N}]/gu, '').toLowerCase();
          const hot = cue.emphasis?.some((e) => e.toLowerCase() === clean);
          return (
            <span key={i} style={{color: hot ? ACCENT : '#fff'}}>
              {w}{' '}
            </span>
          );
        })}
      </div>
    </AbsoluteFill>
  );
};
