import {interpolate, spring, Easing} from 'remotion';

/** Bekukan frame ke kelipatan `step` -> kesan stop-motion ("on twos/threes"). */
export const hold = (frame: number, step = 2) => Math.floor(frame / step) * step;

/** Kemunculan "pop" dengan overshoot (squash & stretch halus). Hasil 0 -> 1. */
export const popIn = (frame: number, fps: number, delay = 0) =>
  spring({
    frame: frame - delay,
    fps,
    config: {damping: 9, stiffness: 160, mass: 0.7},
  });

/** Interpolasi aman: dikunci di rentang input, dengan easing opsional. */
export const ramp = (
  frame: number,
  from: number,
  to: number,
  a: number,
  b: number,
  easing: (t: number) => number = Easing.inOut(Easing.cubic),
) =>
  interpolate(frame, [from, to], [a, b], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
    easing,
  });

/** Goyangan lembut berbasis sinus (napas / melambai). */
export const wobble = (frame: number, period: number, amp: number, phase = 0) =>
  Math.sin(((frame + phase) / period) * Math.PI * 2) * amp;

/** Getar acak deterministik (aman untuk render paralel). */
export const jitter = (seed: number) => {
  const x = Math.sin(seed * 127.1) * 43758.5453;
  return x - Math.floor(x);
};
