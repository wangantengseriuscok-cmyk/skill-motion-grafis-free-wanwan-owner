// Palet "DNA visual": tinta gelap keunguan + warna datar yang bersih.
export const INK = '#1B1530';

export const SKIN = {
  light: '#F6C896',
  mid: '#EDAE7C',
  deep: '#C98657',
};

export const DAY = {
  skyTop: '#5FB0FF',
  skyBottom: '#C6E6FF',
  mountainFar: '#9DB6D3',
  mountainNear: '#7F9CBF',
  haze: '#E8F2FF',
  grass: '#46A233',
  grassDark: '#2F7F27',
  pine: '#2E7D32',
  trunk: '#8A5A2B',
  path: '#D9B27C',
};

export const NIGHT = {
  wall: '#2F4B80',
  wood: '#7A4A24',
  clockRim: '#B8281E',
};

export const UNIFORM = {
  shirt: '#F7F7FB',
  navy: '#243A73',
  tagCard: '#C9A06A',
};
