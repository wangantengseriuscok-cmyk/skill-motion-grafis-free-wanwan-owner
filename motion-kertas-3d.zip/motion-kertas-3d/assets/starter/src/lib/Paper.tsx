import React from 'react';
import {AbsoluteFill} from 'remotion';

// Tekstur serat kertas statis (SVG noise) untuk di-multiply di atas seluruh frame.
const grainSvg = encodeURIComponent(
  `<svg xmlns='http://www.w3.org/2000/svg' width='300' height='300'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='2' seed='4'/><feColorMatrix values='0 0 0 0 0.5  0 0 0 0 0.45  0 0 0 0 0.4  0 0 0 0.9 0'/></filter><rect width='300' height='300' filter='url(#n)'/></svg>`,
);

export const PaperGrain: React.FC<{opacity?: number}> = ({opacity = 0.22}) => (
  <AbsoluteFill
    style={{
      backgroundImage: `url("data:image/svg+xml;utf8,${grainSvg}")`,
      mixBlendMode: 'multiply',
      opacity,
      pointerEvents: 'none',
    }}
  />
);

export const Vignette: React.FC<{strength?: number}> = ({strength = 0.35}) => (
  <AbsoluteFill
    style={{
      background: `radial-gradient(ellipse at 50% 45%, rgba(0,0,0,0) 55%, rgba(10,6,30,${strength}) 100%)`,
      pointerEvents: 'none',
    }}
  />
);

/** Color grade: warna overlay dengan blend mode (malam = biru, siang = hangat). */
export const Grade: React.FC<{color: string; mode?: React.CSSProperties['mixBlendMode']; opacity?: number}> = ({
  color,
  mode = 'multiply',
  opacity = 1,
}) => (
  <AbsoluteFill style={{background: color, mixBlendMode: mode, opacity, pointerEvents: 'none'}} />
);

/** Bayangan kontak di lantai: elips blur, mengecil saat karakter melompat. */
export const GroundShadow: React.FC<{w: number; h?: number; squash?: number; opacity?: number}> = ({
  w,
  h = w * 0.16,
  squash = 1,
  opacity = 0.35,
}) => (
  <div
    style={{
      width: w * squash,
      height: h * squash,
      borderRadius: '50%',
      background: `rgba(15,10,40,${opacity})`,
      filter: 'blur(10px)',
    }}
  />
);

/** Stiker kertas bertulisan (motion graphic): kartu miring dengan garis tinta. */
export const PaperSign: React.FC<{
  text: string;
  fill?: string;
  color?: string;
  size?: number;
  rotate?: number;
  scale?: number;
}> = ({text, fill = '#FFD84D', color = '#1B1530', size = 74, rotate = -5, scale = 1}) => (
  <div
    style={{
      display: 'inline-block',
      padding: `${size * 0.22}px ${size * 0.5}px`,
      background: fill,
      color,
      border: `${Math.max(6, size * 0.1)}px solid #1B1530`,
      borderRadius: size * 0.35,
      fontFamily: '"Poppins","Montserrat","Arial Black",sans-serif',
      fontWeight: 900,
      fontSize: size,
      letterSpacing: 1,
      transform: `rotate(${rotate}deg) scale(${scale})`,
      boxShadow: '10px 14px 0 rgba(15,10,40,0.28)',
      whiteSpace: 'nowrap',
    }}
  >
    {text}
  </div>
);
