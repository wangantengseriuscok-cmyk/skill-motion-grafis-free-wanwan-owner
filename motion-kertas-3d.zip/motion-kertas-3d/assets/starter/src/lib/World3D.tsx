import React from 'react';
import {AbsoluteFill, useVideoConfig} from 'remotion';

/**
 * Dunia 3D dari kertas: setiap elemen adalah "lembar" datar (SVG/HTML) yang
 * ditaruh di kedalaman (z) berbeda di dalam satu scene CSS 3D. Kamera = transform
 * pada dunia, jadi parallax, dolly, dan putaran kecil muncul secara alami.
 */
export const PERSPECTIVE = 1400;

export interface Cam {
  x: number; // geser kamera ke kanan (truck)
  y: number; // geser kamera ke bawah (pedestal)
  z: number; // maju (+) / mundur (-) = dolly
  rotX: number; // derajat, tilt
  rotY: number; // derajat, orbit kecil -> ketebalan kertas terlihat
  rotZ?: number; // derajat, dutch angle
}

export const World: React.FC<{cam: Cam; children: React.ReactNode}> = ({cam, children}) => (
  <AbsoluteFill style={{overflow: 'hidden', perspective: PERSPECTIVE, perspectiveOrigin: '50% 50%'}}>
    <AbsoluteFill
      style={{
        transformStyle: 'preserve-3d',
        transform: `translate3d(${-cam.x}px, ${-cam.y}px, ${cam.z}px) rotateX(${cam.rotX}deg) rotateY(${cam.rotY}deg) rotateZ(${cam.rotZ ?? 0}deg)`,
      }}
    >
      {children}
    </AbsoluteFill>
  </AbsoluteFill>
);

export interface LayerProps {
  /** Posisi pusat lembar relatif ke tengah layar, dalam px desain (pada z=0). */
  x?: number;
  y?: number;
  /** Kedalaman: negatif = jauh dari kamera. */
  z?: number;
  w: number;
  h: number;
  /**
   * fit=true: lembar di-scale supaya terlihat sebesar ukuran desain walau jauh.
   * Pakai untuk latar (langit, gunung). Untuk objek dekat biarkan false.
   */
  fit?: boolean;
  blur?: number; // depth of field
  rotX?: number;
  rotY?: number;
  rotZ?: number;
  opacity?: number;
  origin?: string;
  thickness?: number; // jumlah salinan gelap di belakang -> tepi kertas
  children: React.ReactNode;
}

export const Layer: React.FC<LayerProps> = ({
  x = 0,
  y = 0,
  z = 0,
  w,
  h,
  fit = false,
  blur = 0,
  rotX = 0,
  rotY = 0,
  rotZ = 0,
  opacity = 1,
  origin = '50% 50%',
  thickness = 0,
  children,
}) => {
  const {width, height} = useVideoConfig();
  const comp = fit ? (PERSPECTIVE - z) / PERSPECTIVE : 1;
  const left = width / 2 + x * comp - w / 2;
  const top = height / 2 + y * comp - h / 2;
  const edges: React.ReactNode[] = [];
  for (let i = thickness; i >= 1; i--) {
    edges.push(
      <div
        key={i}
        style={{
          position: 'absolute',
          inset: 0,
          transform: `translateZ(${-i * 2.5}px)`,
          filter: 'brightness(0.55) saturate(0.8)',
        }}
      >
        {children}
      </div>,
    );
  }
  return (
    <div
      style={{
        position: 'absolute',
        left,
        top,
        width: w,
        height: h,
        opacity,
        transformStyle: 'preserve-3d',
        transformOrigin: origin,
        transform: `translateZ(${z}px) rotateX(${rotX}deg) rotateY(${rotY}deg) rotateZ(${rotZ}deg) scale(${comp})`,
        filter: blur > 0 ? `blur(${blur}px)` : undefined,
      }}
    >
      {edges}
      <div style={{position: 'absolute', inset: 0}}>{children}</div>
    </div>
  );
};
