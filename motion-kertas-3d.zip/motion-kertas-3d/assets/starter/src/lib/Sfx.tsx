import React from 'react';
import {Audio, Sequence, staticFile, interpolate, useVideoConfig} from 'remotion';

export interface SfxCue {
  at: number; // detik, saat benturan visual terjadi
  file: string; // nama file di public/sfx/
  volume?: number; // 0..1 (relatif terhadap voice over)
  rate?: number; // playbackRate, variasikan 0.92-1.08 agar tak monoton
  lead?: number; // detik mulai lebih awal (whoosh biasanya 0.08-0.15)
}

/** Semua SFX dari satu daftar cue -> mudah disetel & dibaca. */
export const SfxTrack: React.FC<{cues: SfxCue[]}> = ({cues}) => {
  const {fps} = useVideoConfig();
  return (
    <>
      {cues.map((c, i) => (
        <Sequence key={i} from={Math.max(0, Math.round((c.at - (c.lead ?? 0)) * fps))} layout="none">
          <Audio src={staticFile(`sfx/${c.file}`)} volume={c.volume ?? 0.6} playbackRate={c.rate ?? 1} />
        </Sequence>
      ))}
    </>
  );
};

/** Musik latar dengan ducking otomatis saat voice over bicara. */
export const Music: React.FC<{
  file: string;
  base?: number;
  duck?: number;
  speech: Array<[number, number]>; // [mulai, selesai] detik saat narator bicara
}> = ({file, base = 0.28, duck = 0.12, speech}) => {
  const {fps, durationInFrames} = useVideoConfig();
  return (
    <Audio
      src={staticFile(file)}
      volume={(f) => {
        const t = f / fps;
        // jarak (detik) ke rentang bicara terdekat; 0 = sedang bicara. Turun cepat, naik pelan.
        const dist = Math.min(...speech.map(([a, b]) => (t < a ? a - t : t > b ? t - b : 0)));
        const ducked = interpolate(dist, [0, 0.35], [duck, base], {extrapolateRight: 'clamp'});
        const fadeOut = interpolate(f, [durationInFrames - fps * 0.8, durationInFrames], [1, 0], {
          extrapolateLeft: 'clamp',
        });
        return ducked * fadeOut;
      }}
    />
  );
};
