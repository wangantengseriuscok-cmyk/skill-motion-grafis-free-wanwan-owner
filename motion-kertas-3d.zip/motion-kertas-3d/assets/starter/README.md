# Starter Motion Kertas 3D

Proyek Remotion siap pakai: karakter kertas 2D di dunia berlapis 3D, subtitle, SFX.

```bash
npm install
npm run sfx          # buat SFX placeholder ke public/sfx (ganti dengan SFX berlisensi nanti)
npm run dev          # Remotion Studio (pratinjau interaktif)
npm run typecheck
npx remotion still src/index.ts HermawanIntro out/still.png --frame=105
npm run render       # -> out/hermawan-intro.mp4
```

Komposisi: `HermawanIntro` (video 10 detik contoh) dan `CharacterSheet` (cek gaya karakter).

Audio opsional (`src/config.ts`): letakkan `public/audio/vo.mp3` / `music.mp3` lalu set flag `true`.

Jika Chrome tidak bisa diunduh atau CPU hanya 1 core:
```bash
npx remotion render src/index.ts HermawanIntro out/video.mp4 \
  --concurrency=1 --browser-executable=/path/ke/chrome-headless-shell --chrome-mode=headless-shell
```
Untuk cerita baru: salin `src/scenes/HermawanIntro.tsx`, ubah hanya bagian "DATA CERITA", daftarkan di `src/Root.tsx`.
