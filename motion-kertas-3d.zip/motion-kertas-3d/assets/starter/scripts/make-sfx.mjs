// Membuat SFX PLACEHOLDER (tanpa dependensi) ke public/sfx/*.wav.
// Tujuannya agar proyek langsung bisa dirender dengan bunyi. Untuk hasil final,
// ganti dengan SFX berlisensi (lihat references/sfx-audio.md) memakai nama file yang sama.
import {mkdirSync, writeFileSync} from 'node:fs';

const SR = 44100;
const out = 'public/sfx';
mkdirSync(out, {recursive: true});

let seed = 1337;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296) * 2 - 1;
const buf = (sec) => new Float32Array(Math.floor(sec * SR));
const exp = (t, k) => Math.exp(-t * k);

function write(name, data) {
  let peak = 0;
  for (const v of data) peak = Math.max(peak, Math.abs(v));
  const g = peak > 0 ? 0.8 / peak : 1;
  const pcm = Buffer.alloc(44 + data.length * 2);
  pcm.write('RIFF', 0);
  pcm.writeUInt32LE(36 + data.length * 2, 4);
  pcm.write('WAVEfmt ', 8);
  pcm.writeUInt32LE(16, 16);
  pcm.writeUInt16LE(1, 20);
  pcm.writeUInt16LE(1, 22);
  pcm.writeUInt32LE(SR, 24);
  pcm.writeUInt32LE(SR * 2, 28);
  pcm.writeUInt16LE(2, 32);
  pcm.writeUInt16LE(16, 34);
  pcm.write('data', 36);
  pcm.writeUInt32LE(data.length * 2, 40);
  for (let i = 0; i < data.length; i++) pcm.writeInt16LE(Math.max(-1, Math.min(1, data[i] * g)) * 32767, 44 + i * 2);
  writeFileSync(`${out}/${name}.wav`, pcm);
  console.log('ok', name);
}

// pop: sapuan nada turun cepat
{
  const d = buf(0.18);
  let ph = 0;
  for (let i = 0; i < d.length; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (180 + 700 * exp(t, 38))) / SR;
    d[i] = Math.sin(ph) * exp(t, 22) + (i < 60 ? rnd() * 0.3 : 0);
  }
  write('pop', d);
}
// whoosh: noise dengan filter yang menyapu naik lalu turun
{
  const d = buf(0.55);
  let lp = 0;
  for (let i = 0; i < d.length; i++) {
    const t = i / d.length;
    const env = Math.sin(Math.PI * t) ** 2;
    const a = 0.05 + 0.5 * Math.sin(Math.PI * t);
    lp += a * (rnd() - lp);
    d[i] = lp * env;
  }
  write('whoosh', d);
}
// ding: lonceng kecil
{
  const d = buf(1.0);
  for (let i = 0; i < d.length; i++) {
    const t = i / SR;
    d[i] = (Math.sin(2 * Math.PI * 1320 * t) + 0.4 * Math.sin(2 * Math.PI * 1980 * t) + 0.2 * Math.sin(2 * Math.PI * 2640 * t)) * exp(t, 5);
  }
  write('ding', d);
}
// boing: pegas
{
  const d = buf(0.55);
  let ph = 0;
  for (let i = 0; i < d.length; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (210 + 90 * Math.sin(2 * Math.PI * 12 * t) * exp(t, 4))) / SR;
    d[i] = Math.sin(ph) * exp(t, 5);
  }
  write('boing', d);
}
// step: tap langkah
{
  const d = buf(0.14);
  let ph = 0;
  for (let i = 0; i < d.length; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (55 + 60 * exp(t, 40))) / SR;
    d[i] = Math.sin(ph) * exp(t, 30) + rnd() * 0.25 * exp(t, 70);
  }
  write('step', d);
}
// bell: bel sekolah (dering bergetar)
{
  const d = buf(1.3);
  for (let i = 0; i < d.length; i++) {
    const t = i / SR;
    const trem = 0.6 + 0.4 * Math.sin(2 * Math.PI * 17 * t);
    d[i] = (Math.sin(2 * Math.PI * 880 * t) + 0.6 * Math.sin(2 * Math.PI * 1187 * t) + 0.35 * Math.sin(2 * Math.PI * 1760 * t)) * trem * exp(t, 2.6);
  }
  write('bell', d);
}
// confetti: letupan kertas (klik acak yang meluruh)
{
  const d = buf(1.0);
  let prev = 0;
  for (let i = 0; i < d.length; i++) {
    const t = i / SR;
    const n = rnd();
    const hp = n - prev;
    prev = n;
    const gate = Math.abs(rnd()) < 0.18 + 0.7 * exp(t, 8) ? 1 : 0.15;
    d[i] = hp * gate * exp(t, 3.2);
  }
  write('confetti', d);
}
// sparkle: arpeggio naik
{
  const d = buf(0.7);
  const notes = [1760, 2349, 2794, 3520];
  notes.forEach((f, n) => {
    const start = Math.floor(n * 0.07 * SR);
    for (let i = 0; start + i < d.length; i++) {
      const t = i / SR;
      d[start + i] += Math.sin(2 * Math.PI * f * t) * exp(t, 9) * 0.5;
    }
  });
  write('sparkle', d);
}
